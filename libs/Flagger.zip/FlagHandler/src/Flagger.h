#ifndef FLAGGER_H
#define FLAGGER_H

#include <cstdint>

namespace flagger
{
  /// Adds bits indicated by mask to the variable flags
  inline void add(uint8_t &flags, uint8_t mask)
  {
    flags |= mask;
  }

  /// Removes bits indicated by mask from the variable flags
  inline void remove(uint8_t &flags, uint8_t mask)
  {
    flags &= ~mask;
  }

  /// Toggles the bits indicated by mask in the variable flags
  inline void toggle(uint8_t &flags, uint8_t mask)
  {
    flags ^= mask;
  }

  /// Checks if the bits indicated by mask are set in the variable flags
  inline bool has(const uint8_t &flags, uint8_t mask)
  {
    return (flags & mask) == mask;
  }

}

#endif // FLAGGER_H
